-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2020 at 11:35 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Cat_id` int(11) NOT NULL,
  `Cat_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Cat_id`, `Cat_name`) VALUES
(1, 'Turizem Malor'),
(2, 'Turizem Bregdetar'),
(3, 'Turizem Historik');

-- --------------------------------------------------------

--
-- Table structure for table `pakete`
--

CREATE TABLE `pakete` (
  `pak_id` int(11) NOT NULL,
  `em_qyteti` varchar(100) CHARACTER SET latin1 NOT NULL,
  `category` int(100) NOT NULL,
  `cmim_pak` int(200) NOT NULL,
  `img1` varchar(8000) CHARACTER SET latin1 NOT NULL,
  `img2` varchar(8000) CHARACTER SET latin1 NOT NULL,
  `img3` varchar(8000) CHARACTER SET latin1 NOT NULL,
  `img4` varchar(8000) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pakete`
--

INSERT INTO `pakete` (`pak_id`, `em_qyteti`, `category`, `cmim_pak`, `img1`, `img2`, `img3`, `img4`) VALUES
(1, 'Theth', 1, 78, 'theth1.jpg', 'theth2.jpg', 'theth3.jpg', 'theth4.jpeg'),
(2, 'Dajt', 1, 50, 'dajt1.jpg', 'dajt2.jpg', 'dajt3.jpg', 'dajt4.jpg'),
(3, 'Dardhe', 1, 59, 'dardhe1.jpg', 'dardhe2.jpg', 'dardhe3.jpg', 'dardhe4.jpg'),
(4, 'Dhermi', 2, 99, 'dhermi1.jpg', 'dhermi2.jpg', 'dhermi3.jpg', 'dhermi4.jpg'),
(5, 'Durres', 2, 49, 'durres1.jpg', 'durres2.jpg', 'durres3.jpg', 'durres4.jpeg'),
(6, 'Karaburun', 2, 99, 'karaburun1.png', 'karaburun2.jpg', 'karaburun3.jpg', 'karaburun4.jpg'),
(7, 'Shkoder', 3, 60, 'shkoder1.jpg', 'shkoder2.jpg', 'shkoder3.jpg', 'shkoder4.jpg'),
(8, 'Tirane', 3, 54, 'tirane1.jpg', 'tirane2.jpg', 'tirane3.jpg', 'tirane4.jpg'),
(9, 'Vlore', 3, 70, 'vlore1.jpg', 'vlore2.jpg', 'vlore3.jpg', 'vlore4.jpg'),
(10, 'Gjirokaster', 3, 65, 'gjirokaster1.jpg', 'gjirokaster2.jpg', 'gjirokaster3.jpg', 'gjirokaster4.jpg'),
(11, 'Pogradec', 3, 58, 'pogradec1.jpg', 'pogradec2.jpg', 'pogradec3.jpg', 'pogradec4.jpg'),
(12, 'Kruje', 3, 49, 'kruje1.jpg', 'kruje2.jpg', 'kruje3.jpg', 'kruje4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `rezervo`
--

CREATE TABLE `rezervo` (
  `rezervim_id` int(11) NOT NULL,
  `pakete_id` int(50) NOT NULL,
  `emri` varchar(50) NOT NULL,
  `cel` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nr_personave` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rezervo`
--

INSERT INTO `rezervo` (`rezervim_id`, `pakete_id`, `emri`, `cel`, `email`, `nr_personave`) VALUES
(1, 2, 'ana', '0678525278', 'ana@gmail.com', 5),
(2, 2, 'Anisa Leti', '0678525278', 'anisaleti8@gmail.com', 5),
(3, 1, 'usr', '0682547897', 'usr@gmail.com', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Cat_id`);

--
-- Indexes for table `pakete`
--
ALTER TABLE `pakete`
  ADD PRIMARY KEY (`pak_id`);

--
-- Indexes for table `rezervo`
--
ALTER TABLE `rezervo`
  ADD PRIMARY KEY (`rezervim_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pakete`
--
ALTER TABLE `pakete`
  MODIFY `pak_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `rezervo`
--
ALTER TABLE `rezervo`
  MODIFY `rezervim_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
